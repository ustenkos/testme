ENV_KEYS = {
    "current_job_id": "CNVRG_JOB_ID",
    "current_job_type": "CNVRG_JOB_TYPE",
    "current_project": "CNVRG_PROJECT",
    "current_organization": "CNVRG_OWNER"
}
